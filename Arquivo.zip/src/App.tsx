import { useState, useEffect } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'

type GameKey = 'clickCounter' | 'speed' | 'guess' | 'dontClick' | 'mole'

function ClickCounterGame() {
  const [count, setCount] = useState(0)

  const getMessage = () => {
    if (count >= 200) return '💥 INFINITO E ALÉM! 200+ cliques!'
    if (count >= 100) return '🔥 MONSTRO DO CLIQUE! 100+ cliques!'
    if (count >= 50) return '🚀 Turbo ativado, respeita!'
    if (count >= 20) return '😎 Tá embalado(a)!'
    if (count >= 10) return '👏 Passou dos 10, bora mais!'
    if (count > 0) return 'Começou bem 😏'
    return 'Clique para começar o jogo!'
  }

  return (
    <div className="game-card">
      <h2>Jogo 1: Contador Insano</h2>
      <p className="game-desc">Clique sem dó e desbloqueie mensagens secretas.</p>
      <button className="btn-main" onClick={() => setCount((prev) => prev + 1)}>
        Cliques: {count}
      </button>
      <button className="btn-ghost" onClick={() => setCount(0)}>
        Resetar
      </button>
      <p className="game-message">{getMessage()}</p>
    </div>
  )
}

function ClickSpeedGame() {
  const [timeLeft, setTimeLeft] = useState(0)
  const [clicks, setClicks] = useState(0)
  const [bestScore, setBestScore] = useState(0)
  const [isPlaying, setIsPlaying] = useState(false)

  useEffect(() => {
    if (!isPlaying || timeLeft <= 0) return

    const interval = setInterval(() => {
      setTimeLeft((t) => t - 1)
    }, 1000)

    return () => clearInterval(interval)
  }, [isPlaying, timeLeft])

  useEffect(() => {
    if (timeLeft === 0 && isPlaying) {
      setIsPlaying(false)
      setBestScore((prev) => (clicks > prev ? clicks : prev))
    }
  }, [timeLeft, isPlaying, clicks])

  const startGame = () => {
    setClicks(0)
    setTimeLeft(10)
    setIsPlaying(true)
  }

  const handleClick = () => {
    if (!isPlaying) return
    setClicks((c) => c + 1)
  }

  const getRank = () => {
    if (clicks >= 80 || bestScore >= 80) return '⚡ HOMEM / MULHER FLASH'
    if (clicks >= 50 || bestScore >= 50) return '🔥 Dedo de titânio'
    if (clicks >= 30 || bestScore >= 30) return '💪 Rápido(a) demais'
    if (bestScore > 0) return 'Tá esquentando ainda...'
    return 'Aperta em começar e vamos ver!'
  }

  return (
    <div className="game-card">
      <h2>Jogo 2: Desafio dos 10 segundos ⏱️</h2>
      <p className="game-desc">Quantos cliques você consegue em 10 segundos?</p>
      <button className="btn-main" onClick={startGame} disabled={isPlaying}>
        {isPlaying ? 'Jogando...' : 'Começar'}
      </button>

      <div className="speed-container">
        <div className="speed-info">
          <p>Tempo restante: {timeLeft}s</p>
          <p>Cliques nessa rodada: {clicks}</p>
          <p>Recorde: {bestScore}</p>
        </div>
        <button
          className="btn-big"
          onClick={handleClick}
          disabled={!isPlaying}
        >
          CLIQUE AQUI!
        </button>
      </div>

      <p className="game-message">{getRank()}</p>
    </div>
  )
}

function GuessNumberGame() {
  const [secret, setSecret] = useState(() => Math.floor(Math.random() * 10) + 1)
  const [guess, setGuess] = useState('')
  const [message, setMessage] = useState('Tente adivinhar um número de 1 a 10!')
  const [tries, setTries] = useState(0)

  const handleGuess = () => {
    const num = Number(guess)
    if (!num || num < 1 || num > 10) {
      setMessage('Coloca um número entre 1 e 10, né 😅')
      return
    }

    setTries((t) => t + 1)

    if (num === secret) {
      setMessage(`ACERTOU! 🎉 Era ${secret}. Você tentou ${tries + 1} vez(es).`)
    } else if (num < secret) {
      setMessage('É MAIOR 👆')
    } else {
      setMessage('É MENOR 👇')
    }
  }

  const resetGame = () => {
    setSecret(Math.floor(Math.random() * 10) + 1)
    setGuess('')
    setMessage('Novo número gerado! Tente adivinhar de 1 a 10.')
    setTries(0)
  }

  return (
    <div className="game-card">
      <h2>Jogo 3: Adivinha o Número 🎯</h2>
      <p className="game-desc">Chuta o número secreto e prova que é vidente.</p>
      <div className="guess-row">
        <input
          type="number"
          value={guess}
          onChange={(e) => setGuess(e.target.value)}
          min={1}
          max={10}
        />
        <button className="btn-main" onClick={handleGuess}>
          Chutar
        </button>
        <button className="btn-ghost" onClick={resetGame}>
          Novo número
        </button>
      </div>
      <p className="game-message">{message}</p>
      <p className="tries">Tentativas: {tries}</p>
    </div>
  )
}

function DontClickGame() {
  const [seconds, setSeconds] = useState(0)
  const [clicked, setClicked] = useState(false)

  useEffect(() => {
    if (clicked) return
    const interval = setInterval(() => {
      setSeconds((s) => s + 1)
    }, 1000)
    return () => clearInterval(interval)
  }, [clicked])

  const handleClick = () => {
    setClicked(true)
  }

  const reset = () => {
    setClicked(false)
    setSeconds(0)
  }

  const getMessage = () => {
    if (!clicked) {
      if (seconds === 0) return 'Só NÃO clicar. Parece fácil, né? 🤨'
      if (seconds < 5) return 'Segurou legal… será que aguenta mais?'
      if (seconds < 15) return 'Modo monge zen ativado 🧘‍♂️'
      if (seconds < 30) return 'Você é uma muralha! 🧱'
      return 'Ok, você desbloqueou o nível “sem vida” 😂'
    } else {
      return `VOCÊ NÃO RESISTIU 😈 Durou ${seconds} segundo(s).`
    }
  }

  return (
    <div className="game-card">
      <h2>Jogo 4: NÃO CLIQUE NO BOTÃO VERMELHO 🚨</h2>
      <p className="game-desc">Quanto tempo você consegue NÃO apertar?</p>
      <div className="dont-click-info">
        <p>Tempo sem clicar: {seconds}s</p>
        <p className="game-message">{getMessage()}</p>
      </div>
      <div className="dont-click-buttons">
        <button
          className={`btn-danger ${clicked ? 'btn-danger-broken' : ''}`}
          onClick={handleClick}
          disabled={clicked}
        >
          NÃO CLIQUE
        </button>
        <button className="btn-ghost" onClick={reset}>
          Resetar
        </button>
      </div>
    </div>
  )
}

function MoleGame() {
  const [activeIndex, setActiveIndex] = useState(() => Math.floor(Math.random() * 9))
  const [score, setScore] = useState(0)
  const [miss, setMiss] = useState(0)

  const handleCellClick = (index: number) => {
    if (index === activeIndex) {
      setScore((s) => s + 1)
      setActiveIndex(Math.floor(Math.random() * 9))
    } else {
      setMiss((m) => m + 1)
    }
  }

  const resetGame = () => {
    setScore(0)
    setMiss(0)
    setActiveIndex(Math.floor(Math.random() * 9))
  }

  const getMessage = () => {
    if (score >= 20) return 'God gamer 🎮'
    if (score >= 10) return 'Reflexo de pro player 😎'
    if (score >= 5) return 'Tá indo bem, continua!'
    if (score > 0) return 'Aquecendo reflexo...'
    return 'Clique no quadrado brilhando!'
  }

  return (
    <div className="game-card">
      <h2>Jogo 5: Whack-a-Quadradinho 🧱</h2>
      <p className="game-desc">Clique sempre no quadrado aceso o mais rápido possível.</p>
      <div className="mole-stats">
        <span>Pontos: {score}</span>
        <span>Erros: {miss}</span>
      </div>
      <div className="mole-grid">
        {Array.from({ length: 9 }).map((_, index) => (
          <button
            key={index}
            className={`mole-cell ${index === activeIndex ? 'mole-active' : ''}`}
            onClick={() => handleCellClick(index)}
          />
        ))}
      </div>
      <button className="btn-ghost" onClick={resetGame}>
        Resetar
      </button>
      <p className="game-message">{getMessage()}</p>
    </div>
  )
}

function App() {
  const [activeGame, setActiveGame] = useState<GameKey>('clickCounter')

  const games: { key: GameKey; title: string; subtitle: string; emoji: string }[] =
    [
      {
        key: 'clickCounter',
        title: 'Contador Insano',
        subtitle: 'Clique infinito e mensagens secretas',
        emoji: '🔥',
      },
      {
        key: 'speed',
        title: 'Desafio 10s',
        subtitle: 'Clique mais rápido que todo mundo',
        emoji: '⏱️',
      },
      {
        key: 'guess',
        title: 'Adivinha Número',
        subtitle: '1 a 10, confia no feeling',
        emoji: '🎯',
      },
      {
        key: 'dontClick',
        title: 'Botão Vermelho',
        subtitle: 'Só não clicar. Simples. Ou não.',
        emoji: '🚨',
      },
      {
        key: 'mole',
        title: 'Whack-a-Quadradinho',
        subtitle: 'Reflexo de pro player',
        emoji: '🧱',
      },
    ]

  const renderGame = () => {
    switch (activeGame) {
      case 'clickCounter':
        return <ClickCounterGame />
      case 'speed':
        return <ClickSpeedGame />
      case 'guess':
        return <GuessNumberGame />
      case 'dontClick':
        return <DontClickGame />
      case 'mole':
        return <MoleGame />
      default:
        return null
    }
  }

  return (
    <div className="app-root">
      <div className="bg-animated" />

      <header className="header">
        <div className="logo-row">
          <a href="https://vite.dev" target="_blank">
            <img src={viteLogo} className="logo logo-spin" alt="Vite logo" />
          </a>
          <a href="https://react.dev" target="_blank">
            <img src={reactLogo} className="logo logo-pulse" alt="React logo" />
          </a>
        </div>
        <h1 className="title">Liz Arcade 🎮</h1>
        <p className="subtitle">
          SITE DA Liz REXPEITA NOIX — escolhe um jogo e sai clicando.
        </p>
      </header>

      <main className="main">
        <section className="game-selector">
          {games.map((game) => (
            <button
              key={game.key}
              className={`game-tab ${
                activeGame === game.key ? 'game-tab-active' : ''
              }`}
              onClick={() => setActiveGame(game.key)}
            >
              <span className="game-tab-emoji">{game.emoji}</span>
              <div className="game-tab-text">
                <span className="game-tab-title">{game.title}</span>
                <span className="game-tab-subtitle">{game.subtitle}</span>
              </div>
            </button>
          ))}
        </section>

        <section className="game-container">{renderGame()}</section>
      </main>

      <footer className="footer">
        <p>
          Feito em React + Vite. Se chegou até aqui é porque você clicou demais 😜
        </p>
      </footer>
    </div>
  )
}

export default App
